#!/bin/bash

function install() {
echo "execution ${FUNCTIONNAME} - start"
echo "installing ${1}" #it will pass the argument from outside funtion
echo "execution ${FUNCTIONAME} -  END"

} 

function configure() {
echo "execution ${FUNCTIONNAME} - start"
echo "configure ${1}" #it will pass the argument from outside funtion
echo "execution ${FUNCTIONAME} -  END"

}

function deploy() {
echo "execution ${FUNCTIONNAME} - start"
echo "deployment ${1}" #it will pass the argument from outside funtion
echo "execution ${FUNCTIONAME} -  END"

}
install "nginx" #argument
configure "nginx"
deploy "nginx"


