#!/bin/bash
string="abcakashsinghabcxyz"
echo "${string:1}"
echo "${string:3:3}"
echo "${string:  -5}"
echo "${string#a*s}" #from starting, shortest match
echo "${string##a*c}" #from starting, longest match
echo "${string:  -5}

echo "${string%a*s}"  #from ending,  shortest match
echo "${string%%a*c}"  #from ending, longest match

