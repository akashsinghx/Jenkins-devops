#!/bin/bash

echo "hello world"
pwd
ls -l

yum install ngnix -y
