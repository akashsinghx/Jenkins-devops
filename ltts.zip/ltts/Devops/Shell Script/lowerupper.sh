#!/bin/bash

string="akash Singh"
echo "hello ${string}"

#for first string letter uppercase
echo "hello ${string^}"
#for all string value upper ^^
echo "hello ${string^^}"

#for first letter of string lower
echo "hello ${string,}"
#for all string in lower case
echo "hello ${string,,}"

