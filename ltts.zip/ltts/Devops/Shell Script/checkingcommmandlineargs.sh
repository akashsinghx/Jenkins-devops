#!/bi/bash

echo ${0}
echo ${1}
