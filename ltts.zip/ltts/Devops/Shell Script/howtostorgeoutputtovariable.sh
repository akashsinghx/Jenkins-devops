#!/bin/bash

pwd

CURRENT_WORKING_DIR=`pwd`
#$(pwd)

echo "${CURRENT_WORKING_DIR}"
