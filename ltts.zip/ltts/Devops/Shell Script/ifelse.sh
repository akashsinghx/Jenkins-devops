#!/bin/bash

if echo "hello world"
then 
	echo "working fine"
else
	echo "not working fine "
fi
