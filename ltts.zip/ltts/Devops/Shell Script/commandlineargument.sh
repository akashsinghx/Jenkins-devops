#!/bin/bash

name="akash"
surname="Singh"

echo ${0}
echo ${1}

