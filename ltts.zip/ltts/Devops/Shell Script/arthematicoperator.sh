#!/bin/bash

a=15
b=25
echo "$((a+b))"
