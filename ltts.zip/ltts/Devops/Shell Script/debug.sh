#!/bin/bash

echo "my name is akash"
var=5

echo "var is $var"
idk
#to check debug use bash -x debug.sh
#debug check all the lines and give the output correspondingly

#set -x to check line wise line 
#set -xe to exit after getting error
