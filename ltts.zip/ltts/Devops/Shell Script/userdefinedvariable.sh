#!/bin/bash

name="akash"
age="22"
job="work"
echo "my name is $name and my age is $age and currently i am ${job}ing "
