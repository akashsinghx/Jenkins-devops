#!/bin/bash

if [[ $UDI == 0 ]]
then 
	echo "you are root user"
else
	echo "you are not a root user"
fi
