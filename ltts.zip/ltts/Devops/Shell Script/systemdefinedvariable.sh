#!/bin/bash
echo "$SHELL"
echo "$UID"
echo "$HOME"
echo "$PATH"
echo ${$}
echo "$PPID"
echo "$PWD"
echo "$HOSTNAME"
echo "$OSTYPE"
