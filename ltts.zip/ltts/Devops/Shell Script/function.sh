#!/bin/bash

function install() {
echo "hello this is install stage"
}

configuration() { 
echo "hello this is configuration stage"
}

function deploy {
echo "hello this is deploy stage"
install #we can define function in another funtion
}

install
configuration
deploy
