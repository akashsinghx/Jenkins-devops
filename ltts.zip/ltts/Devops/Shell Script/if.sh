#!/bin/bash

if echo "hello world"
then 
	echo "yes the command is working"
fi
echo "No command is not working"
