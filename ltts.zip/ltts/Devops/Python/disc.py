disk = {
    "diskname" : "HDD",
    "disksize" : "128gb"
}