Here, you can find all the cheatsheat 
